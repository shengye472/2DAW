package com.daw.mi_proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiProyectoApplication.class, args);
	}

}
