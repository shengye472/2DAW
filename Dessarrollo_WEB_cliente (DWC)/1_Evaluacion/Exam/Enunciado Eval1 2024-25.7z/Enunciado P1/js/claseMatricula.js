// Definicion clase Matricula		
class Matricula {
	constructor() {
	}

	anyadeModulo(codigo) {
	}

	borraModulo(codigo) {
	}

	verMatricula() {
	}

}