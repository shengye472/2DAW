modulos = [{
	'codigo': 1,
	'nombre': 'Cliente',
	'creditos': 10
},
{
	'codigo': 2,
	'nombre': 'Servidor',
	'creditos': 8
},
{
	'codigo': 3,
	'nombre': 'Interfaces',
	'creditos': 6
},
{
	'codigo': 4,
	'nombre': 'Despliegue',
	'creditos': 4
},
{
	'codigo': 5,
	'nombre': 'Empresa',
	'creditos': 4
},
{
	'codigo': 6,
	'nombre': 'Ingles',
	'creditos': 2
}]