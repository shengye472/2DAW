class Carrito{
	constructor(id){						
	}
						
	anyadeArticulo(articulo){		
		}			
				
	borraArticulo(codigo){		
	}
	
	modificaUnidades(codigo,n){		
	}	
			
	verCarrito(){
	}			
}
