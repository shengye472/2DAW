	criterios=["Sin ordenar","Ascendente por precio", "Descendente por precio"]
	
	function creaListaCriterios(){
		
	}


	function pintaArticulos(orden){
		
	}
	
	
	function ponArticuloEnCarrito(){
		
	}


	function verCarro(){
	
	}

	function efectuaPedido(){
	
	}

	window.onload=()=>{

	}

