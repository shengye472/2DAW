import { Component } from '@angular/core';
import { Articulo } from '../../interfaces/articulo';
import { ARTICULOS } from '../../Datos/articulos';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-articulos',
  imports: [FormsModule],
  templateUrl: './articulos.component.html',
  styleUrl: './articulos.component.css'
})
export class ArticulosComponent {

  articulos: Articulo[] = ARTICULOS
  articulo: Articulo = this.articulos[0]
  id: string = this.articulo.id

  ngOnInit() {
    console.log(this.articulos)
  }

  comprar(articulo: Articulo) {
    alert("Lo has comprado.")
  }

  ver() {
    let miArticulo = this.articulos.find(a => a.id == this.id)
    if (miArticulo)
      this.articulo = miArticulo
    else
      alert("Error. No exisate el articulo " + this.id)
  }

  suma() {
    this.articulo.unidades++
  }
  resta() {
    this.articulo.unidades--
  }


}
