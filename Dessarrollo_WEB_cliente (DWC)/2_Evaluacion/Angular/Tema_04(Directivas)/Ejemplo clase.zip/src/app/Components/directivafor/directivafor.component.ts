import { Component } from '@angular/core';

@Component({
  selector: 'app-directivafor',
  imports: [],
  templateUrl: './directivafor.component.html',
  styleUrl: './directivafor.component.css'
})
export class DirectivaforComponent {

}
