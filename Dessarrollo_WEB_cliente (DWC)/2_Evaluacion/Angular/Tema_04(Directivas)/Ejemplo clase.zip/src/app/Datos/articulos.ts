import { Articulo } from "../interfaces/articulo";

export const ARTICULOS: Articulo[] =
    [

    ]
