export interface Tarea {
    id: string;
    nombre: string;
    estado: string;
}
