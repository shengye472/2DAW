package com.fpMislata.domain.usecase;

import com.fpMislata.domain.entity.Order;

import java.util.List;

public interface OrderGetAllUseCase {
    List<Order> getAll();
}
