package com.fpmislata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
