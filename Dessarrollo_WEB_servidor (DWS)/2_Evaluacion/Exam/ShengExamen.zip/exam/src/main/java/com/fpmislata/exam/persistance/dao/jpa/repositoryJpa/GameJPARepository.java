package com.fpmislata.exam.persistance.dao.jpa.repositoryJpa;

import com.fpmislata.exam.persistance.dao.jpa.model.GameEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface GameJPARepository extends JpaRepository<GameEntity, Integer> {
    @Query( value = """
                SELECT *
                FROM games g
                INNER JOIN directors d ON g.director_id = d.id
                WHERE g.game_code = :code;
            """,nativeQuery = true)
    GameEntity findByCode(String code);

}
